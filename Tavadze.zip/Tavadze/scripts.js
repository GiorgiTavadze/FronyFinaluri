
document.addEventListener('DOMContentLoaded', () => {
  if (document.querySelector('#news-table')) {
      loadNews();
  }

  const urlParams = new URLSearchParams(window.location.search);
  const id = urlParams.get('id');
  if (id) {
      loadNewsForEdit(id);
  }
});

async function loadNews() {
  const response = await fetch('https://btu-exam-cb6c3fdf3b9d.herokuapp.com/news');
  const newsList = await response.json();
  const tableBody = document.querySelector('#news-table tbody');

  newsList.forEach(news => {
      const row = document.createElement('tr');
      row.innerHTML = `
          <td>${news.id}</td>
          <td>${news.title}</td>
          <td>${news.category}</td>
          <td>${news.likes}</td>
          <td>${news.dateUpdated}</td>
          <td>${news.dateCreated}</td>
          <td>
              <button class="delete" onclick="deleteNews(${news.id}, this)">Delete</button>
              <button class="update" onclick="updateNews(${news.id})">Update</button>
          </td>
      `;
      tableBody.appendChild(row);
  });
}

async function deleteNews(id, button) {
  const response = await fetch(`https://btu-exam-cb6c3fdf3b9d.herokuapp.com/news/${id}`, {
      method: 'DELETE'
  });

  if (response.ok) {
      const row = button.closest('tr');
      row.classList.add('fade-out');
      setTimeout(() => row.remove(), 500);
  }
}

function updateNews(id) {
  window.location.href = `create.html?id=${id}`;
}

async function loadNewsForEdit(id) {
  const response = await fetch(`https://btu-exam-cb6c3fdf3b9d.herokuapp.com/news/${id}`);
  const news = await response.json();

  document.getElementById('title').value = news.title;
  document.getElementById('description').value = news.description;
  document.getElementById('category').value = news.category;
  document.getElementById('editorFirstName').value = news.editorFirstName;
  document.getElementById('editorLastName').value = news.editorLastName;
}

async function saveNews() {
  const title = document.getElementById('title').value;
  const description = document.getElementById('description').value;
  const category = document.getElementById('category').value;
  const editorFirstName = document.getElementById('editorFirstName').value;
  const editorLastName = document.getElementById('editorLastName').value;

  const urlParams = new URLSearchParams(window.location.search);
  const id = urlParams.get('id');
  const method = id ? 'PUT' : 'POST';
  const url = id 
      ? `https://btu-exam-cb6c3fdf3b9d.herokuapp.com/news/${id}`
      : 'https://btu-exam-cb6c3fdf3b9d.herokuapp.com/news';

  const response = await fetch(url, {
      method: method,
      headers: {
          'Content-Type': 'application/json'
      },
      body: JSON.stringify({ title, description, category, editorFirstName, editorLastName })
  });

  if (response.ok) {
      window.location.href = 'main.html';
  } else {
      alert('Failed to save news');
  }
}

function cancel() {
  window.location.href = 'main.html';
}
